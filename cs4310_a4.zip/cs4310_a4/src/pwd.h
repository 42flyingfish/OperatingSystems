#ifndef PWD_H
#define PWD_H

void pwd();

#endif