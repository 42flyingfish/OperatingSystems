#ifndef CD_H
#define CD_H

void cd(char *args);

#endif
