#ifndef MKDIR_H
#define MKDIR_H

// Name was chosen not to conflict with mkdir()
void cppmkdir(char *path);

#endif
