#ifndef LS_H
#define LS_H

void ls(char *args);

#endif
