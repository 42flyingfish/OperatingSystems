#ifndef RMDIR_H
#define RMDIR_H

void cpprmdir(char *args);


#endif
