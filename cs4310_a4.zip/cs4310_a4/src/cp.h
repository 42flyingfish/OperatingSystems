#ifndef CP_H
#define CP_H

void cp(char *sourcePath, char *targetPath);

#endif
